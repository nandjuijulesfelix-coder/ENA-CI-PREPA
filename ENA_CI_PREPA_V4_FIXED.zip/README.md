# ENA CI Prépa V4.1
Version corrigée sans dépendance AndroidX/AppCompat pour éviter le conflit de dépendances observé dans le premier build.
