# ENA CI Prépa V5

Application Android de préparation au concours ENA Côte d'Ivoire.

Fonctions V5:
- Parcours Présélection / Admissibilité / Admission
- QCM par matière avec corrections et explications
- Matières par cycle Supérieur, Moyen Supérieur et Moyen
- Examen blanc chronométré
- Coaching oral
- Progression locale
- Lien vers les communiqués officiels de l'ENA

Build:
Le workflow GitHub Actions construit l'APK debug.
