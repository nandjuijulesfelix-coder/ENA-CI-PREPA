# ENA CI Prépa V6

Version mobile de préparation au concours ENA Côte d’Ivoire.

Contenu :
- plus de 150 questions d’entraînement originales ;
- présélection : culture générale, aptitudes verbales, logique/aptitudes numériques, anglais ;
- matières d’admissibilité par cycle ;
- examens blancs chronométrés ;
- fiches rapides ;
- coaching oral ;
- progression locale ;
- lien vers les communiqués officiels de l’ENA.

Compilation prévue via GitHub Actions.
