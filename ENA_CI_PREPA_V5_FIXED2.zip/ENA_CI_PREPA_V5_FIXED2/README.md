# ENA CI Prépa V5 FIXED

Version V5 corrigée pour éviter les conflits de classes.
- Dépendance AndroidX AppCompat supprimée (l'application utilise Activity/WebView natifs).
- Gradle 8.10.2 utilisé avec Android Gradle Plugin 8.6.1.
- QCM, corrections, examen blanc, coaching oral et progression locale conservés.
